# Tutorial de uso y Chaos QA

## Flujo normal
1. Abra la aplicación.
2. Complete título y descripción.
3. Elija entre 1 y 5 preguntas.
4. Configure cada pregunta como Choice, Sí/No o Texto Libre.
5. En Choice use punto y coma: `opcion1;opcion2`.
6. Pulse **Guardar localmente**.
7. Recargue la página y confirme que el registro continúa en la lista.

## Editar
1. Seleccione un registro.
2. Pulse **Editar**.
3. Modifique campos.
4. Pulse **Guardar localmente**.

## Borrar
1. Seleccione un registro.
2. Pulse **Borrar**.

## Chaos QA
### Cargar datos extremos
Carga textos largos, emojis y caracteres especiales. El objetivo es comprobar que la interfaz siga siendo usable y que las validaciones funcionen.

### Duplicar próximo guardado
Activa una duplicación controlada. Sirve para demostrar cómo detectar un defecto de doble envío o falta de idempotencia.

### Generar 50 registros
Agrega volumen local al listado. Sirve para validar scroll, estabilidad visual y tiempos de interacción.

### Restablecer
Elimina los datos generados y recupera la base inicial.

## Datos locales
El proyecto usa LocalStorage. No comparte datos entre equipos y no envía información a un servidor.
